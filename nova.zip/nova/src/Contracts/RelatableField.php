<?php

namespace Laravel\Nova\Contracts;

interface RelatableField
{
    //
}
