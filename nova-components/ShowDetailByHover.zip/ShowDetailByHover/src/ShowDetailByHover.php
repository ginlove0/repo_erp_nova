<?php

namespace Ipsupply\ShowDetailByHover;

use Laravel\Nova\Fields\Field;

class ShowDetailByHover extends Field
{
    /**
     * The field's component.
     *
     * @var string
     */
    public $component = 'show-detail-by-hover';
}
