<template>
    <div>
        <heading class="mb-6">Add item manualy</heading>

            <p v-if="errors.length">
                    <b>Please correct the following error(s):</b>
                <ul>
                    <li v-for="error in errors" style="color: red">{{ error }}</li>
                </ul>
            </p>


        <div>
            <table class="table-detail">
                <tbody>
                    <tr class="table-row">
                        <td class="row">
                            <label> Model: </label>
                            <Dropdown
                                id="model-dropdown"
                                :options="models"
                                v-on:selected="validateSelectionModel"
                                v-on:filter="getDropdownValuesInModel"
                                :disabled="false"
                                placeholder="Please select model">
                            </Dropdown>
                        </td>

                        <td class="row">
                            <label> Condition: </label>
                            <select v-model="items[0].conditionId" class="w-full form-control form-input form-input-bordered class-select">
                                <option value="1000">NIB</option>
                                <option value="1500">NOB</option>
                                <option value="2750">USEA</option>
                                <option selected value="3000">USEB</option>
                                <option value="4000">USEC</option>
                                <option value="5001">REF</option>
                                <option value="5000">PART</option>
                            </select>
                        </td>
                    </tr>
                    <tr class="table-row">

                        <td class="row">
                            <label> Supplier: </label>
                            <Dropdown
                                id="supplier-dropdown"
                                :options="suppliers"
                                v-on:selected="validateSelectionSupplier"
                                v-on:filter="getDropdownValuesInSupplier"
                                :disabled="false"
                                placeholder="Please select supplier">
                            </Dropdown>
                        </td>

                        <td class="row">
                            <label > Wh Location:</label>
                            <select v-model="items[0].whlocationId" class="w-full form-control form-input form-input-bordered class-select">
                                <option value="1">Sydney</option>
                                <option value="2">US</option>

                            </select>
                        </td>
                    </tr>
                    <tr class="table-row">
                        <td class="input-col" colspan="12">
                            <label>Serial Number:</label>
                            <textarea
                                id="input-serialNumber"
                                type="text"
                                class="w-full form-control form-input form-input-bordered"
                                :class="errorClasses"
                                v-model="items.serialNumber"
                            ></textarea>
                        </td>
                    </tr>

                    <tr>
                        <td class="note-col" colspan="12">
                            <label>Note:</label>
                            <textarea
                                id="input-note"
                                type="text"
                                class="w-full form-control form-input form-input-bordered"
                                :class="errorClasses"
                                v-model="items[0].note">
                            </textarea>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div>
            <button type="button" @click="handleSubmit"  class="w-full btn btn-group-lg btn-primary">
                Submit
            </button>
        </div>
    </div>

</template>

<script>
    import Dropdown from "./SearchCreation";
    export default {
        props: ['resourceName', 'resourceId', 'field'],

        components: {Dropdown},

        data(){
            return{
                items: [{
                    serialNumber: '',
                    aliasModel: '',
                    whlocationid: '',
                    modelId: '',
                    supplierId: '',
                    conditionId: 3000,
                    note: ''
                }],
                models: [],
                suppliers: [],
                arrayItem: [],
                errors: [],
                countArray: []

            }

        },


        methods: {

            handleSubmit() {
                this.errors = [];
                if(!this.items[0].modelId)
                {
                    this.errors.push('Model is required!')
                }
                if(!this.items[0].supplierId)
                {
                    this.errors.push('Supplier is required!')
                }
                if(!this.items.serialNumber)
                {
                    this.errors.push('Serial number is required!')
                }

                const replaced_space_sn = this.items.serialNumber.replace(/\n/gi, " ");
                const replaced_comma_sn = replaced_space_sn.replace(/,/g, " ");
                const arr_sn = replaced_comma_sn.split(' ');
                this.arrayItem = _.uniq(arr_sn);
                this.countArray = [];

                this.arrayItem.map((newItem) => {
                    if(newItem.length > 0){
                        this.items[0].serialNumber = newItem.trim();
                        this.countArray.push(newItem.trim());
                        axios.get('/nova-vendor/warehouse-transfer-tool/addItemToStock/'+ JSON.stringify(this.items[0]))
                            .then((res) => {
                                // console.log(res)
                            })
                            .catch((err) => {
                                console.log(err.message)
                            })
                    }

                })
                this.items = [{serialNumber: '', aliasModel: '', modelId: '', supplierId: '', conditionId: 3000, note: '', whlocationid: ''}]
                alert('Added ' + this.countArray.length + ' items in stock');

            },

            getAllSupplier(){
                axios.get('/nova-vendor/warehouse-transfer-tool/timThuXemNhe/findAllSupplierInDB')
                    .then((res) => {
                        console.log(res)
                        this.suppliers = res.data
                    })
                    .catch((err) => {
                        console.log(err.message)
                    })
            },

            //selected model
            validateSelectionSupplier(selection) {
                this.items[0].supplierId = selection.id;
                console.log(selection.name+' has been selected');
            },

            getDropdownValuesInSupplier(keyword) {

                console.log('You could refresh options by querying the API with '+ keyword);

            },


            getAllModel(){
                axios.get('/nova-vendor/warehouse-transfer-tool/findSomething/modelGetAll')
                    .then((res) => {
                        this.models = res.data
                    })
                    .catch((err) => {
                        console.log(err.message)
                    })
            },

            //selected model
            validateSelectionModel(selection) {
                this.items[0].modelId = selection.id;
                console.log(selection.name+' has been selected');
            },

            getDropdownValuesInModel(keyword) {

                console.log('You could refresh options by querying the API with '+ keyword);

            },
        },

        mounted() {
            //
            this.getAllModel()
            this.getAllSupplier()
        },

        computed: {


        }
    }
</script>

<style>
    /* Scoped Styles */


    #input-serialNumber {
        height: 200px;
        display: inline;
    }


    #input-note {
        height: 70px;
    }

    label {
        font-family: monospace;
        font-size: 17px;
    }

    .btn {
        height: 50px;
        font-size: 17px;
        font-family: monospace;
    }

    .table-detail {
        margin-left: auto;
        margin-right: auto;
        width: 100%;
    }

    .class-select {
        border: 1px solid;
    }








</style>
