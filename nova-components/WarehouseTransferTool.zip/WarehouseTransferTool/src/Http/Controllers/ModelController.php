<?php


namespace Ipsupply\WarehouseTransferTool\Http\Controllers;


use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;

class ModelController extends Controller
{
    public function show()
    {
        $datas = DB::select('SELECT name, id FROM model');

        return $datas;
    }
}
