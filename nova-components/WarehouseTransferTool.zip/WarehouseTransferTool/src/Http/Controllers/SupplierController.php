<?php


namespace Ipsupply\WarehouseTransferTool\Http\Controllers;


use App\Services\Supplier\SupplierServiceInterface;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SupplierController extends Controller
{

    public function show()
    {
        $datas = DB::select('SELECT name, id FROM supplier');

        return $datas;
    }
}
