<?php

namespace Ipsupply\ItemToOutStock;

use Laravel\Nova\Fields\Field;

class ItemToOutStock extends Field
{
    /**
     * The field's component.
     *
     * @var string
     */
    public $component = 'item-to-out-stock';
}
