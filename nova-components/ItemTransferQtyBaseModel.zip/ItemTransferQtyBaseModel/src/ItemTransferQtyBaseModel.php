<?php

namespace Ipsupply\ItemTransferQtyBaseModel;

use Laravel\Nova\Fields\Field;

class ItemTransferQtyBaseModel extends Field
{
    /**
     * The field's component.
     *
     * @var string
     */
    public $component = 'item-transfer-qty-base-model';
}
