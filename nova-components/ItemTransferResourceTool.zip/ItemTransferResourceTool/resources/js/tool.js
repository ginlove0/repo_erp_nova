Nova.booting((Vue, router, store) => {
  Vue.component('item-transfer-resource-tool', require('./components/Tool'))
})
