<?php

namespace Ipsupply\WarehouseTransferField;

use Laravel\Nova\Fields\Field;

class WarehouseTransferField extends Field
{
    /**
     * The field's component.
     *
     * @var string
     */
    public $component = 'warehouse-transfer-field';
}
