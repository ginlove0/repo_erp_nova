Nova.booting((Vue, router, store) => {
  Vue.component('wh_transfer_item_packed_resource_tool', require('./components/Tool'))
})
